package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicio.CSVSerializable;
import servicio.Gestionable;

public class GestorReservas<T extends CSVSerializable> implements Gestionable<T>{
    
    List<T> listaViajes = new ArrayList<>();

    
    private void validarIndice(int indice){
        if(indice < 0 || indice >= listaViajes.size()){
            throw new IndexOutOfBoundsException("indice fuera de rango: " + indice);
        }
    }  
    
    @Override
    public void agregar(T elemento) {
        if (elemento == null){
            System.out.println("Error, no puedo agregar un elemento de tipo null");
        }
        listaViajes.add(elemento);
    }

    @Override
    public T eliminar(int indice) {
        validarIndice(indice);
        return listaViajes.remove(indice);
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return listaViajes.get(indice);
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        listaViajes.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        
        for (T e : listaViajes){
            if(predicate.test(e)){
                toReturn.add(e);
            }
        } return toReturn;
    }

    @Override
    public List<T> transformarElementos(Function<T, T> function) {
        List<T> toReturn = new ArrayList<>();
        
        for(T item: listaViajes){
            toReturn.add(function.apply(item));
        
        }return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) throws IOException {
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path));
        
        salida.writeObject(listaViajes);
        salida.close();
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        listaViajes.clear();
        
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path));
        
        listaViajes = (List<T>) entrada.readObject();
        entrada.close();
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
        BufferedWriter buffer = new BufferedWriter(new FileWriter(path));
    
        for( T item: listaViajes){
            buffer.write(item.toCSV() + "\n");
        }
        
        buffer.close();
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformadora) throws IOException {
        listaViajes.clear();
        try{
            BufferedReader buffer = new BufferedReader(new FileReader(path));
    
            String linea = "";
            while((linea = buffer.readLine()) != null){
                listaViajes.add(transformadora.apply(linea));
            }

            buffer.close();
        
        } catch( FileNotFoundException e){
            System.out.println(e.getMessage());
        }    
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumer) {
        for(T item: listaViajes){
            consumer.accept(item);
            }
    }
    
    public void mostrarTodos(){
        paraCadaElemento(reserva -> System.out.println(reserva));
    }
    
    
}
