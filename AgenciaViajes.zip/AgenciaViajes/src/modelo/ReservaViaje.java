package modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;
import servicio.CSVSerializable;

public class ReservaViaje extends Reserva implements Serializable, CSVSerializable, Comparable<ReservaViaje>{
    
    private String destino;
    private TipoTransporte transporte;
    private static final long SerialVersionUID = 1L;

    public ReservaViaje(int id, String pasajero, LocalDate fecha, String destino, TipoTransporte transporte) {
        super(id, pasajero, fecha);
        this.destino = destino;
        this.transporte = transporte;
    }

    @Override
    public String toCSV() {
        return super.toCSV() + destino + "," + transporte;
    }

    
    @Override
    public int compareTo(ReservaViaje otro) {
        return getFecha().compareTo(otro.getFecha());
    }

    
    @Override
    public String toString() {
        return "ReservaViaje - id: " + getId() + ",pasajero: " + getPasajero() + ",fecha: " + getFecha() + 
                ",destino: " + destino + ",transporte: " + transporte;
    }

    
    public static ReservaViaje fromCSV(String reservaViajeCSV){
            String[] values = reservaViajeCSV.split(",");
            ReservaViaje toReturn = null;
            if(values.length == 5){
                int id = Integer.parseInt(values[0]);
                String pasajero = values[1];
                LocalDate fecha = LocalDate.parse(values[2]);
                String destino = values[3];
                TipoTransporte transporte = TipoTransporte.valueOf(values[4]);
                
                toReturn = new ReservaViaje(id, pasajero, fecha, destino, transporte);
        }
        return toReturn;
    }
    
    public String getDestino() {
        return destino;
    }

    public TipoTransporte getTransporte() {
        return transporte;
    }    
        
}
