package configuracion;

public class AppConfig {
    
    public static final String PATH_BIN = "src/data/viajes.dat";
    public static final String PATH_CSV = "src/data/viajes.csv";
    
}
